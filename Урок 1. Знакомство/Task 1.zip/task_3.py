a = input("Введите число n")

b = int(a+a)
c = int(a+a+a)

print(int(a)+b+c)

