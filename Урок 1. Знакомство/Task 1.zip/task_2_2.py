a = int(input("Введите число"))

print ("Вы ввели:{}".format(a))
print ("Ответ: {}:{}:{}".format(a//3600,(a%3600)//60,a%60))
